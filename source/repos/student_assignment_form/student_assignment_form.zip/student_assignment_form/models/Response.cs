﻿namespace student_assignment_form.models
{
    public class Response
    {
        public dynamic Value { get; set; }
        public string Error { get; set; }
    }
}
