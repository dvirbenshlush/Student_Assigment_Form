export interface IStudent {
    
    identify : number,
    firstName : string,
    lastName : string,
    gender : string,
    institution : string,
    birthday : Date,
    homeNumber : number,
    mobile : number,
    email : string,
    country : string,
    immigration : Date,
    nation : string,
    Register : boolean,

}